/*
 * drivers/amlogic/securitykey/securitykey.c
 *
 * Copyright (C) 2015 Amlogic, Inc. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
*/

#include <linux/errno.h>
#include <linux/err.h>
#include <linux/of.h>
#include <linux/of_fdt.h>
#include <linux/libfdt_env.h>
#include <linux/of_reserved_mem.h>
#include <linux/io.h>
#include <linux/platform_device.h>
/*#include <asm/compiler.h>*/
#include <linux/spinlock.h>
#include <linux/amlogic/security_key.h>
#undef pr_fmt
#define pr_fmt(fmt) "storage: " fmt

#define __asmeq(x, y)  ".ifnc " x "," y " ; .err ; .endif\n\t"

static void __iomem *storage_in_base;
static void __iomem *storage_out_base;
static void __iomem *storage_block_base;

static long phy_storage_in_base;
static long phy_storage_out_base;
static long phy_storage_block_base;
static long storage_block_size;

static unsigned long storage_read_func;
static unsigned long storage_write_func;
static unsigned long storage_query_func;
static unsigned long storage_tell_func;
static unsigned long storage_status_func;
static unsigned long storage_verify_func;
static unsigned long storage_list_func;
static unsigned long storage_remove_func;

static DEFINE_SPINLOCK(storage_lock);
static unsigned long lockflags;

static uint64_t storage_smc_ops(uint64_t func)
{
	register unsigned long x0 asm("x0") = func;
	asm volatile(
		__asmeq("%0", "x0")
		"smc	#0\n"
		: "+r" (x0));

	return x0;
}

static inline int32_t smc_to_linux_errno(uint64_t errno)
{
	int32_t ret = (int32_t)(errno & 0xffffffff);
	return ret;
}

void *secure_storage_getbuffer(uint32_t *size)
{
	*size = storage_block_size;
	return (void *)storage_block_base;
}

int32_t secure_storage_write(uint8_t *keyname, uint8_t *keybuf,
			uint32_t keylen, uint32_t keyattr)
{
	uint32_t *input;
	uint32_t namelen;
	uint8_t *keydata, *name;
	uint64_t ret;

	spin_lock_irqsave(&storage_lock, lockflags);
	namelen = strlen((const char *)keyname);
	input = (uint32_t *)storage_in_base;
	*input++ = namelen;
	*input++ = keylen;
	*input++ = keyattr;
	name = (uint8_t *)input;
	memcpy(name, keyname, namelen);
	keydata = name + namelen;
	memcpy(keydata, keybuf, keylen);
	ret = storage_smc_ops(storage_write_func);
	spin_unlock_irqrestore(&storage_lock, lockflags);
	return smc_to_linux_errno(ret);
}

int32_t secure_storage_read(uint8_t *keyname, uint8_t *keybuf,
				uint32_t keylen, uint32_t *readlen)
{
	uint32_t *input = (uint32_t *)storage_in_base;
	uint32_t *output = (uint32_t *)storage_out_base;
	uint32_t namelen;
	uint8_t *name, *buf;
	uint64_t ret;

	spin_lock_irqsave(&storage_lock, lockflags);
	namelen = strlen((const char *)keyname);
	*input++ = namelen;
	*input++ = keylen;
	name = (uint8_t *)input;
	memcpy(name, keyname, namelen);
	ret = storage_smc_ops(storage_read_func);
	if (ret == RET_OK) {
		*readlen = *output;
		buf = (uint8_t *)(output + 1);
		memcpy(keybuf, buf, *readlen);
	}
	spin_unlock_irqrestore(&storage_lock, lockflags);
	return smc_to_linux_errno(ret);
}

int32_t secure_storage_verify(uint8_t *keyname, uint8_t *hashbuf)
{
	uint32_t *input = (uint32_t *)storage_in_base;
	uint32_t *output = (uint32_t *)storage_out_base;
	uint32_t namelen;
	uint8_t *name;
	uint64_t ret;

	spin_lock_irqsave(&storage_lock, lockflags);
	namelen = strlen((const char *)keyname);
	*input++ = namelen;
	name = (uint8_t *)input;
	memcpy(name, keyname, namelen);
	ret = storage_smc_ops(storage_verify_func);
	if (ret == RET_OK)
		memcpy(hashbuf, (uint8_t *)output, 32);
	spin_unlock_irqrestore(&storage_lock, lockflags);

	return smc_to_linux_errno(ret);
}

int32_t secure_storage_query(uint8_t *keyname, uint32_t *retval)
{
	uint32_t *input = (uint32_t *)storage_in_base;
	uint32_t *output = (uint32_t *)storage_out_base;
	uint32_t namelen;
	uint8_t *name;
	uint64_t ret;

	spin_lock_irqsave(&storage_lock, lockflags);
	namelen = strlen((const char *)keyname);
	*input++ = namelen;
	name = (uint8_t *)input;
	memcpy(name, keyname, namelen);
	ret = storage_smc_ops(storage_query_func);
	if (ret == RET_OK)
		*retval = *output;
	spin_unlock_irqrestore(&storage_lock, lockflags);

	return smc_to_linux_errno(ret);
}

int32_t secure_storage_tell(uint8_t *keyname, uint32_t *retval)
{
	uint32_t *input = (uint32_t *)storage_in_base;
	uint32_t *output = (uint32_t *)storage_out_base;
	uint32_t namelen;
	uint8_t *name;
	uint64_t ret;

	spin_lock_irqsave(&storage_lock, lockflags);
	namelen = strlen((const char *)keyname);
	*input++ = namelen;
	name = (uint8_t *)input;
	memcpy(name, keyname, namelen);
	ret = storage_smc_ops(storage_tell_func);
	if (ret == RET_OK)
		*retval = *output;
	spin_unlock_irqrestore(&storage_lock, lockflags);
	return smc_to_linux_errno(ret);
}

int32_t secure_storage_status(uint8_t *keyname, uint32_t *retval)
{
	uint32_t *input = (uint32_t *)storage_in_base;
	uint32_t *output = (uint32_t *)storage_out_base;
	uint32_t namelen;
	uint8_t *name;
	uint64_t ret;

	spin_lock_irqsave(&storage_lock, lockflags);
	namelen = strlen((const char *)keyname);
	*input++ = namelen;
	name = (uint8_t *)input;
	memcpy(name, keyname, namelen);
	ret = storage_smc_ops(storage_status_func);
	if (ret == RET_OK)
		*retval = *output;
	spin_unlock_irqrestore(&storage_lock, lockflags);
	return smc_to_linux_errno(ret);
}

int32_t secure_storage_list(uint8_t *listbuf,
		uint32_t buflen, uint32_t *readlen)
{
	uint32_t *output = (uint32_t *)storage_out_base;
	uint64_t ret;

	spin_lock_irqsave(&storage_lock, lockflags);
	ret = storage_smc_ops(storage_list_func);
	if (ret == RET_OK) {
		if (*output > buflen)
			*readlen = buflen;
		else
			*readlen = *output;
		memcpy(listbuf, (uint8_t *)(output+1), *readlen);
	}
	spin_unlock_irqrestore(&storage_lock, lockflags);
	return smc_to_linux_errno(ret);
}

int32_t secure_storage_remove(uint8_t *keyname)
{
	uint32_t *input = (uint32_t *)storage_in_base;
	uint32_t namelen;
	uint8_t *name;
	uint64_t ret;

	spin_lock_irqsave(&storage_lock, lockflags);
	namelen = strlen((const char *)keyname);
	*input++ = namelen;
	name = (uint8_t *)input;
	memcpy(name, keyname, namelen);
	ret = storage_smc_ops(storage_remove_func);
	spin_unlock_irqrestore(&storage_lock, lockflags);
	return smc_to_linux_errno(ret);
}
static int storage_probe(struct platform_device *pdev)
{
	struct device_node *np = pdev->dev.of_node;
	unsigned int id;
	int ret;

	if (!of_property_read_u32(np, "storage_in_func", &id))
		phy_storage_in_base = storage_smc_ops(id);
	if (!of_property_read_u32(np, "storage_out_func", &id))
		phy_storage_out_base = storage_smc_ops(id);
	if (!of_property_read_u32(np, "storage_block_func", &id))
		phy_storage_block_base = storage_smc_ops(id);
	if (!of_property_read_u32(np, "storage_size_func", &id))
		storage_block_size = storage_smc_ops(id);

	if (!of_property_read_u32(np, "storage_read", &id))
		storage_read_func = id;
	if (!of_property_read_u32(np, "storage_write", &id))
		storage_write_func = id;
	if (!of_property_read_u32(np, "storage_query", &id))
		storage_query_func = id;
	if (!of_property_read_u32(np, "storage_tell", &id))
		storage_tell_func = id;
	if (!of_property_read_u32(np, "storage_status", &id))
		storage_status_func = id;
	if (!of_property_read_u32(np, "storage_verify", &id))
		storage_verify_func = id;
	if (!of_property_read_u32(np, "storage_list", &id))
		storage_list_func = id;
	if (!of_property_read_u32(np, "storage_remove", &id))
		storage_remove_func = id;

	storage_in_base = ioremap_cache(phy_storage_in_base,
					storage_block_size);
	storage_out_base = ioremap_cache(phy_storage_out_base,
					storage_block_size);
	storage_block_base = ioremap_cache(phy_storage_block_base,
					storage_block_size);
	pr_info("storage in base: 0x%lx\n", (long)storage_in_base);
	pr_info("storage out base: 0x%lx\n", (long)storage_out_base);
	pr_info("storage block base: 0x%lx\n", (long)storage_block_base);

	ret = 0;
	if (!storage_in_base || !storage_out_base || !storage_block_base)
		ret = -1;
	pr_info("probe done!\n");
	return ret;
}

static const struct of_device_id securitykey_dt_match[] = {
	{ .compatible = "aml, securitykey" },
	{ /* sentinel */ },
};

static  struct platform_driver securitykey_platform_driver = {
	.probe		= storage_probe,
	.driver		= {
		.owner		= THIS_MODULE,
		.name		= "securitykey",
		.of_match_table	= securitykey_dt_match,
	},
};

int __init meson_securitykey_init(void)
{
	return  platform_driver_register(&securitykey_platform_driver);
}
module_init(meson_securitykey_init);
