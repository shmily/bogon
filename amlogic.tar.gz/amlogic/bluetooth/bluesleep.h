#ifndef _BLUESLEEP_H
#define _BLUESLEEP_H
#include <linux/serial_core.h>
extern struct uart_port *get_uart_port(int id);
#endif
